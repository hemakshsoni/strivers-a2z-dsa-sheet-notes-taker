// =========================================================================
// PART 1: EXTENSION WORLD (Has permissions to talk to local HTTP server)
// =========================================================================
const LOCAL_SERVER = "http://127.0.0.1:27182/note";

// Listen for the "whisper" from the Main World
window.addEventListener("message", function(event) {
  // Only accept messages from our own webpage and with our specific tag
  if (event.source !== window || !event.data || event.data.type !== "DSA_SHEET_NOTE_SAVE") {
    return;
  }

  const { q_id, q_data } = event.data;
  console.log(`[A2Z Sheet Notes] Extension received note for Q-ID ${q_id}. Forwarding to local server...`);

  // Forward the data to your local Node server
  fetch(LOCAL_SERVER, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ q_id, q_data })
  })
  .then(res => {
    if (res.ok) showToast("✅ Note saved locally");
    else showToast("⚠️ Server error", "error");
  })
  .catch((e) => {
    console.error("[A2Z Sheet Notes] Fetch to local server failed:", e);
    showToast("❌ Local server not running", "error");
  });
});

function showToast(message, type = "success") {
  const existing = document.getElementById("a2z-notes-toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.id = "a2z-notes-toast";
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px;
    background: ${type === "error" ? "#ef4444" : "#22c55e"};
    color: white; padding: 10px 16px; border-radius: 8px;
    font-size: 14px; font-family: sans-serif; z-index: 999999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3); transition: opacity 0.3s;
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// =========================================================================
// PART 2: MAIN WORLD INJECTION (Hijacks React's network requests)
// =========================================================================
const injectionCode = `
  function extractData(body) {
    if (!body) return null;
    try {
      if (typeof body === 'string') {
        const parsed = JSON.parse(body);
        if (parsed.q_id) return { q_id: parsed.q_id, q_data: parsed.q_data };
      }
    } catch (e) {}
    try {
      if (typeof body === 'string') {
        const params = new URLSearchParams(body);
        if (params.has('q_id')) return { q_id: params.get('q_id'), q_data: params.get('q_data') };
      }
    } catch (e) {}
    try {
      if (body instanceof FormData) {
        if (body.has('q_id')) return { q_id: body.get('q_id'), q_data: body.get('q_data') };
      }
    } catch(e) {}
    return null;
  }

  // Intercept Fetch
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const [resource, config] = args;
    const url = typeof resource === "string" ? resource : resource?.url;
    const method = (config?.method || resource?.method || "GET").toUpperCase();

    if (url && url.includes("notes") && (method === "PUT" || method === "POST")) {
      console.log("[A2Z Sheet Notes] Main World caught a save!");
      const data = extractData(config?.body);
      if (data && data.q_id && data.q_data) {
          // Whisper the data back up to the Extension World
          window.postMessage({ type: "DSA_SHEET_NOTE_SAVE", q_id: data.q_id, q_data: data.q_data }, "*");
      }
    }
    return originalFetch.apply(this, args);
  };

  // Intercept XHR
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._method = method;
    this._url = url;
    return originalXHROpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (body) {
    if (this._url && this._url.includes("notes") && (this._method?.toUpperCase() === "PUT" || this._method?.toUpperCase() === "POST")) {
      console.log("[A2Z Sheet Notes] Main World caught an XHR save!");
      const data = extractData(body);
      if (data && data.q_id && data.q_data) {
          // Whisper the data back up to the Extension World
          window.postMessage({ type: "DSA_SHEET_NOTE_SAVE", q_id: data.q_id, q_data: data.q_data }, "*");
      }
    }
    return originalXHRSend.apply(this, arguments);
  };
`;

// Inject the Main World script into the page
const script = document.createElement('script');
script.textContent = injectionCode;
(document.head || document.documentElement).appendChild(script);
script.remove();

console.log("[A2Z Sheet Notes] Bridge extension successfully initialized!");