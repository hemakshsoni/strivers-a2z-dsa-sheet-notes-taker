// Runs in MAIN world — can intercept fetch but has NO chrome.* APIs
// Communicates with content-extension.js via window.postMessage

function extractData(body) {
  if (!body) return null;
  try {
    if (typeof body === 'string') {
      const parsed = JSON.parse(body);
      if (parsed.q_id) return { q_id: parsed.q_id, q_data: parsed.q_data };
    }
  } catch (e) {}
  return null;
}

// Intercept fetch
const originalFetch = window.fetch;
window.fetch = async function (...args) {
  const [resource, config] = args;
  const url = typeof resource === "string" ? resource : resource?.url;
  const method = (config?.method || "GET").toUpperCase();

  if (url?.includes("notes") && (method === "PUT" || method === "POST")) {
    const data = extractData(config?.body);
    if (data?.q_id && data?.q_data) {
      // Whisper to extension world via postMessage
      window.postMessage({ type: "DSA_SHEET_NOTE_SAVE", q_id: data.q_id, q_data: data.q_data }, "*");
    }
  }
  // ALWAYS let original request through
  return originalFetch.apply(this, args);
};

// Intercept XHR
const originalOpen = XMLHttpRequest.prototype.open;
const originalSend = XMLHttpRequest.prototype.send;

XMLHttpRequest.prototype.open = function (method, url, ...rest) {
  this._method = method;
  this._url = url;
  return originalOpen.apply(this, [method, url, ...rest]);
};

XMLHttpRequest.prototype.send = function (body) {
  if (this._url?.includes("notes") && (this._method?.toUpperCase() === "PUT" || this._method?.toUpperCase() === "POST")) {
    const data = extractData(body);
    if (data?.q_id && data?.q_data) {
      window.postMessage({ type: "DSA_SHEET_NOTE_SAVE", q_id: data.q_id, q_data: data.q_data }, "*");
    }
  }
  // ALWAYS let original request through
  return originalSend.apply(this, arguments);
};

console.log("[A2Z Sheet Notes] Main world interceptor active");
