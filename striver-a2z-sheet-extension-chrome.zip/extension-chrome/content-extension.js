// Runs in ISOLATED world — has chrome.* APIs but cannot intercept fetch
// Listens for postMessage from content-main.js and forwards to background

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.type !== "DSA_SHEET_NOTE_SAVE") return;
  const { q_id, q_data } = event.data;
  chrome.runtime.sendMessage({ type: "DSA_SHEET_NOTE_SAVE", q_id, q_data });
});

// Listen for toast response from background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "A2Z_TOAST") showToast(msg.message, msg.status);
});

function showToast(message, type = "success") {
  const existing = document.getElementById("a2z-notes-toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.id = "a2z-notes-toast";
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px;
    background: ${type === "error" ? "#ef4444" : "#22c55e"};
    color: white; padding: 10px 16px; border-radius: 8px;
    font-size: 14px; font-family: sans-serif; z-index: 999999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3); transition: opacity 0.3s;
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

console.log("[A2Z Sheet Notes] Extension world bridge active");
