// A2Z Sheet Notes background service worker (Chrome MV3)
// Receives note data from content script and forwards to local server

const LOCAL_SERVER = "http://127.0.0.1:27182/note";

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type !== "DSA_SHEET_NOTE_SAVE") return;

  fetch(LOCAL_SERVER, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ q_id: msg.q_id, q_data: msg.q_data }),
  })
    .then((res) => {
      const response = res.ok
        ? { type: "A2Z_TOAST", message: "✅ Note saved locally", status: "success" }
        : { type: "A2Z_TOAST", message: "⚠️ Server error", status: "error" };
      chrome.tabs.sendMessage(sender.tab.id, response);
    })
    .catch(() => {
      chrome.tabs.sendMessage(sender.tab.id, {
        type: "A2Z_TOAST",
        message: "❌ Local server not running",
        status: "error",
      });
    });
});
